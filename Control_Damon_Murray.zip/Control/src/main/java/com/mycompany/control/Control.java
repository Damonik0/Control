package com.mycompany.control;
/**
 *
 * @author damon
 */

public class Control {

    public static void main(String[] args) {
        Funcion.funcion(args);
    }
}