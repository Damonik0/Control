package com.mycompany.control;
/**
 *
 * @author damon
 */
import java.util.Scanner;

public class Funcion {
public static void funcion(String[] args) {
        Scanner scan = new Scanner(System.in);
        int numero;
        do {
            System.out.println("Ingrese un numero a invertir (minimo dos digitos y que no termine en 0): ");
            while (!scan.hasNextInt()) {
                System.out.println("Lo ingresado no es un numero. Intentalo de nuevo");
                scan.next();
            }
            numero = scan.nextInt();
            if (numero % 10 == 0 || numero < 10) {
                System.out.println("El numero ingresado no cumple con los requisitos. Intentalo de nuevo.");
            }
        } while (numero % 10 == 0 || numero < 10);

        int numeroInvertido = invertirNumero(numero);
        System.out.println("El numero invertido es " + numeroInvertido);
    }

    public static int invertirNumero(int numero) {
        int invertido = 0, resto;
        while (numero > 0) {
            resto = numero % 10;
            invertido = invertido * 10 + resto;
            numero /= 10;
        }
        return invertido;
    }
}